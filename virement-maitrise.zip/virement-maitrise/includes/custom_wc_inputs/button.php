<?php if (!defined('ABSPATH')) {
    exit;
} ?>
<tr valign="top">
    <th scope="row" class="titledesc">
        <label for="<?php echo esc_attr($field); ?>"><?php echo wp_kses_post($data['title']); ?></label>
        <?php echo wp_kses_post($this->get_tooltip_html($data)); ?>
    </th>
    <td class="forminp">
        <fieldset>
            <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
            <button class="<?php echo esc_attr($data['class']); ?>" type="button" name="<?php echo esc_attr($field); ?>" id="<?php echo esc_attr($field); ?>"
                style="<?php echo esc_attr($data['css']); ?>" <?php echo wp_kses_post($this->get_custom_attribute_html($data)); ?>>
                <?php echo wp_kses_post($data['title']); ?>
            </button>
            <?php echo wp_kses_post($this->get_description_html($data)); ?>
        </fieldset>
    </td>
</tr>