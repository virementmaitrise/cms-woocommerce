<?php if (!defined('ABSPATH')) {
    exit;
} ?>
<tr valign="top">
    <th scope="row" class="titledesc">
        <label for="<?php echo esc_attr($field); ?>"><?php echo wp_kses_post($data['title']); ?></label>
        <?php echo wp_kses_post($this->get_tooltip_html($data)); ?>
    </th>
    <td class="forminp">
        <fieldset>
            <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
            <?php foreach ((array) $data['options'] as $optionKey => $optionValue) { ?>
                <div id="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>_bloc">
                    <div class="radio-button">
                        <input type="radio" id="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>" name="woocommerce_wc_fintecture_gateway_checkout_design_selection" value="<?php echo esc_attr($optionKey); ?>" <?php checked($optionKey, $currentDesign); ?>>
                        <label for="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>"><?php echo esc_html($optionValue); ?></label>
                    </div>
                    <?php if ($optionKey != 'it-st-design') { ?>
                        <div id="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>_suboptions" class="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>_suboptions">
                            <img id="woocommerce_wc_fintecture_gateway_checkout_design_<?php echo esc_attr($optionKey); ?>_img" class="woocommerce_wc_fintecture_gateway_checkout_design_img" src="<?php echo esc_url(plugin_dir_url(__FILE__) . '../../assets/img/admin/checkout_design/' . $optionKey . '_payment_method_description_' . esc_attr($data['iso_code']) . '_soc-gen.svg'); ?>">
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </fieldset>
    </td>
</tr>