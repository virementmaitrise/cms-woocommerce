<?php if (!defined('ABSPATH')) {
    exit;
} ?>
<tr valign="top">
    <th scope="row" class="titledesc">
        <label for="<?php echo esc_attr($field); ?>"><?php echo wp_kses_post($data['title']); ?></label>
        <?php echo wp_kses_post($this->get_tooltip_html($data)); ?>
    </th>
    <td class="forminp">
        <fieldset>
            <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
            <input type="file" accept=".pem" class="<?php echo esc_attr($data['class']); ?>" name="<?php echo esc_attr($field); ?>" id="<?php echo esc_attr($field); ?>"
                style="<?php echo esc_attr($data['css']); ?>" <?php echo wp_kses_post($this->get_custom_attribute_html($data)); ?>>
            <?php
            if (!empty($data['value'])) {
                echo '<span class="fintecture-success"><span class="dashicons dashicons-yes"></span>' . esc_html(__('Private key stored', 'virement-maitrise')) . '</span>';
            }
            ?>
            <?php echo wp_kses_post($this->get_description_html($data)); ?>
        </fieldset>
    </td>
</tr>