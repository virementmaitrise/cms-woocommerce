<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
/**
 * Get system infos
 *
 * @return array<string,mixed> system infos
 */
function fintectureSystemInfos(): array
{
    global $wpdb;
    // Get number of gateways
    $wc = get_wc_instance();
    /** @phpstan-ignore-line */
    if (isset($wc->payment_gateways)) {
        $shopPaymentMethods = \count($wc->payment_gateways->get_available_payment_gateways());
    }
    // Get position of gateway
    $ordering = (array) \get_option('woocommerce_gateway_order');
    $position = $ordering && isset($ordering['wc_fintecture_gateway']) ? $ordering['wc_fintecture_gateway'] : '';
    // Get plugin settings without WC_Settings API
    $options = \get_option('woocommerce_wc_fintecture_gateway_settings');
    $mysqlVersion = $wpdb->db_version();
    if (!$mysqlVersion) {
        $mysqlVersion = '';
    }
    // Checkout design
    $checkoutDesign = $options['checkout_design_selection'] ?? '';
    if ($checkoutDesign === 'it-st') {
        $checkoutDesign = 'ist_long';
    }
    if ($checkoutDesign === 'it-design') {
        $checkoutDesign = 'it';
    }
    // Construct config return
    return ['type' => 'php-wp-wc-sdk-1', 'shop_name' => \get_bloginfo('name'), 'shop_domain' => \get_bloginfo('wpurl'), 'shop_cms' => 'wordpress', 'shop_cms_version' => \get_bloginfo('version'), 'shop_wc_version' => \defined('WC_VERSION') ? \WC_VERSION : '', 'mysql_version' => $mysqlVersion, 'module_version' => \FINTECTURE_WC_PLUGIN_VERSION, 'module_position' => $position, 'shop_payment_methods' => $shopPaymentMethods ?? null, 'module_enabled' => isset($options['enabled']) && $options['enabled'] === 'yes' ? 1 : 0, 'module_production' => isset($options['environment']) && $options['environment'] === 'no' ? 1 : 0, 'module_sandbox_app_id' => $options['test_app_id'] ?? '', 'module_production_app_id' => $options['app_id'] ?? '', 'module_checkout_design' => $checkoutDesign, 'module_force_position' => isset($options['force_position']) && $options['force_position'] === 'yes' ? 1 : 0, 'module_force_position_min_amount' => $options['amount_force_position'] ?? '', 'module_recommended_it' => isset($options['recommend_it_payment_method']) && $options['recommend_it_payment_method'] === 'yes' ? 1 : 0, 'module_accepted_order_state' => $options['accepted_payment'] ?? '', 'module_pending_order_state' => $options['pending_payment'] ?? '', 'module_partial_order_state' => $options['$partial_payment'] ?? '', 'module_overpaid_order_state' => $options['overpaid_payment'] ?? '', 'module_failed_order_state' => $options['failed_payment'] ?? '', 'module_cancelled_order_state' => $options['cancelled_payment'] ?? ''];
}
