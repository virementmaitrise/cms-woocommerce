<?php

namespace FintectureWC;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;
final class Fintecture_Blocks extends AbstractPaymentMethodType
{
    /**
     * @var Fintecture_Post_Payment $gateway
     */
    private $gateway;
    /**
     * @var string $name
     */
    protected $name = 'wc_fintecture_gateway';
    public function initialize(): void
    {
        $this->settings = \get_option("woocommerce_{$this->name}_setting", []);
        $this->gateway = new Fintecture_Post_Payment();
    }
    public function is_active(): bool
    {
        return $this->gateway->is_available();
    }
    /**
     * @return array<string>
     */
    public function get_payment_method_script_handles()
    {
        \wp_register_script('wc_fintecture_gateway-blocks-integration', \plugin_dir_url(__FILE__) . '../../assets/js/new-checkout.js', ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n'], null, \true);
        if (\function_exists('FintectureWC\wp_set_script_translations')) {
            wp_set_script_translations('wc_fintecture_gateway-blocks-integration');
        }
        return ['wc_fintecture_gateway-blocks-integration'];
    }
    /**
     * @return array<string,mixed>
     */
    public function get_payment_method_data()
    {
        $options = \get_option('woocommerce_wc_fintecture_gateway_settings');
        // Checkout design
        $checkoutDesign = $options['checkout_design_selection'];
        // Force position
        $forcePosition = isset($options['force_position']) && $options['force_position'] === 'yes' ? 1 : 0;
        $forcePositionAmount = $options['amount_force_position'] ?? '';
        $enabledForcePosition = \false;
        if ($forcePosition) {
            if (empty($forcePositionAmount)) {
                $forcePositionAmount = 0;
            }
            /** @phpstan-ignore-next-line */
            $cart = get_wc_instance()->cart;
            $cartAmount = $cart->total;
            if ($cartAmount > $forcePositionAmount) {
                $enabledForcePosition = \true;
            }
        }
        // Recommended badge
        $recommendedBadge = isset($options['recommend_it_payment_method']) && $options['recommend_it_payment_method'] === 'yes' ? 1 : 0;
        return ['title' => $this->gateway->title, 'isoCode' => \substr(get_locale(), 0, 2), 'checkoutDesign' => $checkoutDesign, 'enabledForcePosition' => $enabledForcePosition, 'recommendedBadge' => $recommendedBadge, 'recommendedText' => \__('Recommended', 'virement-maitrise'), 'assetsUrl' => \plugin_dir_url(__FILE__) . '../../assets/img/'];
    }
}
\class_alias('FintectureWC\Fintecture_Blocks', 'Fintecture_Blocks', \false);
