<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
\define('FINTECTURE_WC_PLUGIN_VERSION', '3.10.8');
\define('FINTECTURE_PAYMENT_PREFIX', 'SOGE-');
