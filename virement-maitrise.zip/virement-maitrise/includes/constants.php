<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
\define('FINTECTURE_WC_PLUGIN_VERSION', '3.10.6');
\define('FINTECTURE_PAYMENT_PREFIX', 'SOGE-');
