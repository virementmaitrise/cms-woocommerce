<?php

// Keep this file outside of includes folder

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}

function get_wc_instance()
{
    if (function_exists('WC')) {
        return \WC();
    }
}