<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
/**
 * Receive infos delivered to webhook
 *
 * @return array<string,mixed> payment infos
 */
function fintectureWebhook(): array
{
    require_once 'wp-load.php';
    $params = ['state' => isset($_POST['state']) ? \sanitize_text_field($_POST['state']) : '', 'status' => isset($_POST['status']) ? \sanitize_text_field($_POST['status']) : '', 'session_id' => isset($_POST['session_id']) ? \sanitize_text_field($_POST['session_id']) : '', 'customer_id' => isset($_POST['customer_id']) ? \sanitize_text_field($_POST['customer_id']) : '', 'provider' => isset($_POST['provider']) ? \sanitize_text_field($_POST['provider']) : '', 'transfer_state' => isset($_POST['transfer_state']) ? \sanitize_text_field($_POST['transfer_state']) : '', 'received_amount' => isset($_POST['received_amount']) ? (float) \sanitize_text_field($_POST['received_amount']) : '', 'type' => isset($_POST['type']) ? \sanitize_text_field($_POST['type']) : '', 'amount' => isset($_POST['amount']) ? (float) \sanitize_text_field($_POST['amount']) : '', 'last_transaction_amount' => isset($_POST['last_transaction_amount']) ? (float) \sanitize_text_field($_POST['last_transaction_amount']) : ''];
    $order = getOrderBySessionId($params['session_id']);
    if ($order) {
        return ['order' => $order, 'params' => $params];
    }
    return ['params' => $params];
}
/**
 * @param string $sessionId
 *
 * @return WC_Order|false
 */
function getOrderBySessionId($sessionId)
{
    if (!\preg_match('/^[0-9a-f]{32}$/', $sessionId)) {
        return \false;
    }
    $args = ['transaction_id' => $sessionId];
    $query = new \WC_Order_Query($args);
    $orders = $query->get_orders();
    return \is_array($orders) && \count($orders) > 0 ? \array_pop($orders) : \false;
}
