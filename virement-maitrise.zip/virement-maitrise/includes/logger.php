<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
/**
 * This function writes in log file
 *
 * @param mixed $log
 * @since 1.0
 */
function fintectureWriteLog($log): void
{
    if (\defined('WP_DEBUG') && \true === \WP_DEBUG) {
        if (\is_array($log) || \is_object($log)) {
            \error_log('Société Générale - ' . \print_r($log, \true));
        } elseif (\is_string($log)) {
            \error_log('Société Générale - ' . $log);
        }
    }
}
