<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
/**
 * Get payment infos
 *
 * @return array<mixed> payment infos
 */
function fintecturePostPayment(): array
{
    $params = ['state' => isset($_GET['state']) ? \sanitize_text_field($_GET['state']) : '', 'status' => isset($_GET['status']) ? \sanitize_text_field($_GET['status']) : '', 'session_id' => isset($_GET['session_id']) ? \sanitize_text_field($_GET['session_id']) : '', 'customer_id' => isset($_GET['customer_id']) ? \sanitize_text_field($_GET['customer_id']) : '', 'provider' => isset($_GET['provider']) ? \sanitize_text_field($_GET['provider']) : ''];
    if (empty($params['state'])) {
        fintectureWriteLog('Bad format - empty state');
        return [null, null, null];
    }
    // We received the payment
    $decodedState = \json_decode(\base64_decode($params['state']));
    if (!\property_exists($decodedState, 'order_id')) {
        $error = 'Error on payment. State: ' . $decodedState;
        if (!empty($params['status']) && $params['status'] == 'payment_unsuccessful') {
            $error .= ' / Status : ' . $decodedState;
        }
        fintectureWriteLog($error);
        return [null, null, null];
    }
    $orderId = $decodedState->order_id;
    $order = \wc_get_order($orderId);
    return [$order, $orderId, $params['session_id']];
}
