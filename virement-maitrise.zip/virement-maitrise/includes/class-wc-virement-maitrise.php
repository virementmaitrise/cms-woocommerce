<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
use FintectureWC\Fintecture\PisClient;
use FintectureWC\Fintecture\Config\Telemetry;
use FintectureWC\Fintecture\Util\Validation;
use FintectureWC\Fintecture\Util\Crypto;
// Check that WooCommerce class exists
if (!\class_exists('WC_Payment_Gateway')) {
    return;
}
class Fintecture_Post_Payment extends \WC_Payment_Gateway
{
    /**
     * The current version of the plugin
     *
     * @since 1.0
     * @access protected
     * @var string $version The current version of the plugin.
     */
    protected $version;
    /**
     * @var array<string> ALLOWED_WEBHOOK_TYPES
     */
    private const ALLOWED_WEBHOOK_TYPES = ['PayByBank', 'Refund', 'BuyNowPayLater', 'ManualTransfer'];
    /**
     * @var bool $environment
     */
    private $environment;
    /**
     * @var string $appId
     */
    private $appId;
    /**
     * @var string $testAppId
     */
    private $testAppId;
    /**
     * @var string $appSecret
     */
    private $appSecret;
    /**
     * @var string $testAppSecret
     */
    private $testAppSecret;
    /**
     * @var string $appPrivateKey
     */
    private $appPrivateKey;
    /**
     * @var string $testAppPrivateKey
     */
    private $testAppPrivateKey;
    /**
     * @var string $checkoutDesignSelection
     */
    private $checkoutDesignSelection;
    /**
     * @var bool $forcePosition
     */
    private $forcePosition;
    /**
     * @var int $amountForcePosition
     */
    private $amountForcePosition;
    /**
     * @var bool $recommendItPaymentMethod
     */
    private $recommendItPaymentMethod;
    /**
     * @var string $acceptedPayment
     */
    private $acceptedPayment;
    /**
     * @var string $pendingPayment
     */
    private $pendingPayment;
    /**
     * @var string $smartTransferPendingPayment
     */
    private $smartTransferPendingPayment;
    /**
     * @var string $partialPayment
     */
    private $partialPayment;
    /**
     * @var string $overpaidPayment
     */
    private $overpaidPayment;
    /**
     * @var string $failedPayment
     */
    private $failedPayment;
    /**
     * @var string $cancelledPayment
     */
    private $cancelledPayment;
    /**
     * @var string $checkoutErrorUrl
     */
    private $checkoutErrorUrl;
    /**
     * @var array<PisClient> $pisClients
     */
    private $pisClients;
    /**
     * Define the core functionality of the plugin
     *
     * @since 1.0
     */
    public function __construct()
    {
        $this->version = \FINTECTURE_WC_PLUGIN_VERSION;
        $this->id = 'wc_fintecture_gateway';
        $this->icon = '';
        $this->has_fields = \true;
        // set to true to display this template : 'checkout-description.php'
        $this->method_title = \__('Virement Maitrisé', 'virement-maitrise');
        $this->method_description = \__('Virement Maitrisé Plug-in for WooCommerce', 'virement-maitrise');
        $this->supports = ['products', 'refunds'];
        // After init_settings() is called, you can get the settings and load them into variables, e.g:
        // $this->title = $this->get_option('title');
        $this->init_settings();
        // Get setting values
        $this->title = \__('Virement maitrisé', 'virement-maitrise');
        $this->enabled = $this->get_option('enabled', 'no');
        $this->environment = 'yes' === $this->get_option('environment', 'yes');
        $this->appId = $this->get_option('app_id', '');
        $this->testAppId = $this->get_option('test_app_id', '');
        $this->appSecret = $this->get_option('app_secret', '');
        $this->testAppSecret = $this->get_option('test_app_secret', '');
        $this->appPrivateKey = $this->get_option('app_private_key', '');
        $this->testAppPrivateKey = $this->get_option('test_app_private_key', '');
        $this->checkoutDesignSelection = $this->get_option('checkout_design_selection', 'it');
        if ($this->checkoutDesignSelection === 'it-st-short-design') {
            $this->update_option('checkout_design_selection', 'it');
        }
        $this->forcePosition = 'yes' === $this->get_option('force_position', 'no');
        $this->amountForcePosition = (int) $this->get_option('amount_force_position', 0);
        $this->recommendItPaymentMethod = 'yes' === $this->get_option('recommend_it_payment_method', 'no');
        $this->acceptedPayment = $this->get_option('accepted_payment', 'wc-processing');
        $this->pendingPayment = $this->get_option('pending_payment', 'wc-pending');
        $this->smartTransferPendingPayment = $this->get_option('smart_transfer_pending_payment', 'wc-on-hold');
        $this->partialPayment = $this->get_option('partial_payment', 'wc-ftc-partial');
        $this->overpaidPayment = $this->get_option('overpaid_payment', 'wc-ftc-overpaid');
        $this->failedPayment = $this->get_option('failed_payment', 'wc-failed');
        $this->cancelledPayment = $this->get_option('cancelled_payment', 'wc-cancelled');
        $this->checkoutErrorUrl = \wc_get_checkout_url() . '?status=cms_internal_error';
        $this->initPisClient();
        // This basically defines your configuration form which are then loaded with init_form_fields()
        $this->init_form_fields();
        // Webhooks for Virement Maitrisé purposes
        $this->register_hooks();
        if (\is_checkout()) {
            \wp_enqueue_style('wc_gateway_fintecture_shop_css', \plugins_url('assets/css/shop.css', __DIR__));
            \wp_register_script('wc_gateway_fintecture_old-checkout_js', \plugins_url('assets/js/old-checkout.js', __DIR__), ['jquery'], \false, \true);
            \wp_enqueue_script('wc_gateway_fintecture_old-checkout_js');
        }
    }
    /**
     * Enqueues admin scripts
     *
     * @since 1.0
     */
    public function enqueue_scripts(): void
    {
        \wp_register_script('wc_gateway_fintecture_settings_js', \plugins_url('assets/js/admin.js', __DIR__), [], \false, \true);
        \wp_enqueue_script('wc_gateway_fintecture_settings_js');
        \wp_localize_script('wc_gateway_fintecture_settings_js', 'virement_maitrise_vars', ['connection_test_url' => \site_url('/wc-api/fintecture_connection_test'), 'success' => \__('Connection succeeded', 'virement-maitrise'), 'failed' => \__('Connection failed. Have you correctly saved the private key in the Virement Maitrisé Console?', 'virement-maitrise')]);
        \wp_enqueue_style('wc_gateway_fintecture_settings_css', \plugins_url('assets/css/admin.css', __DIR__));
    }
    /**
     * Registers the necessary WooCommerce hooks for the Virement Maitrisé payment module.
     *
     * @access private
     */
    private function register_hooks(): void
    {
        \add_action('woocommerce_api_fintecture_post_payment', [$this, 'post_payment']);
        \add_action('woocommerce_api_fintecture_webhook', [$this, 'webhook']);
        \add_action('woocommerce_api_fintecture_connection_test', [$this, 'connection_test']);
        \add_action('woocommerce_api_fintecture_checkout_event', [$this, 'checkout_event']);
        \add_action('woocommerce_api_fintecture_dropdown_event', [$this, 'dropdown_event']);
        \add_action('woocommerce_order_status_changed', [$this, 'woocommerce_order_status_changed'], 10, 3);
        \add_action('woocommerce_before_thankyou', [$this, 'before_thankyou'], 10);
        \add_action('woocommerce_before_checkout_form', [$this, 'before_checkout_form'], 10);
        if ($this->inFintectureSectionPage()) {
            \add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
            \add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
            // Verify requirements
            \add_action('admin_notices', [$this, 'admin_notices_fintecture']);
        }
    }
    /**
     * Return if we are in the Virement Maitrisé configuration plugin page
     *
     * @return bool
     * @since 1.0
     * @access private
     */
    private function inFintectureSectionPage(): bool
    {
        $params = ['page' => isset($_GET['page']) ? \sanitize_text_field($_GET['page']) : '', 'tab' => isset($_GET['tab']) ? \sanitize_text_field($_GET['tab']) : '', 'section' => isset($_GET['section']) ? \sanitize_text_field($_GET['section']) : ''];
        return !empty($params['page']) && !empty($params['tab']) && !empty($params['section']) && $params['section'] === 'wc_fintecture_gateway';
    }
    /**
     * Add an error to WordPress dashboard (shoul be called in an admin notice hook)
     *
     * @param string $message Error message
     * @param string $type type of notice
     * @access private
     */
    private function add_admin_error(string $message, string $type = 'error'): void
    {
        $message = 'Virement Maitrisé - ' . $message;
        echo '<div class="notice notice-' . \esc_attr($type) . '"><p>' . \wp_kses_post($message) . '</p></div>';
    }
    /**
     * Add an error to WooCommerce admin form
     *
     * @param string $message Error message
     * @access private
     */
    private function add_settings_error(string $message): void
    {
        $message = 'Virement Maitrisé - ' . $message;
        $this->add_error($message);
    }
    /**
     * Add an error message into admin for unreadable sandbox private key
     *
     * @since 3.0
     */
    public function privateKeyErrorSandbox(): void
    {
        $this->add_admin_error(\__('Test mode (sandbox): unable to read the Private Key. Please verify it and re-upload it.', 'virement-maitrise'));
    }
    /**
     * Add an error message into admin for unreadable production private key
     *
     * @since 3.0
     */
    public function privateKeyErrorProduction(): void
    {
        $this->add_admin_error(\__('Production: unable to read the Private Key. Please verify it and re-upload it.', 'virement-maitrise'));
    }
    /**
     * Add an error message into admin for incomplete sandbox credentials
     *
     * @since 3.0
     */
    public function incompleteErrorSandbox(): void
    {
        $this->add_admin_error(\__('Test mode (sandbox): configuration is incomplete, please verify credential fields.', 'virement-maitrise'));
    }
    /**
     * Add an error message into admin for incomplete production credentials
     *
     * @since 3.0
     */
    public function incompleteErrorProduction(): void
    {
        $this->add_admin_error(\__('Production: configuration is incomplete, please verify credential fields.', 'virement-maitrise'));
    }
    /**
     * Call all checks
     */
    public function admin_notices_fintecture(): void
    {
        $this->doCurlCheck();
        $this->doOpensslCheck();
        $this->doPermalinksStructureCheck();
        $this->doPriceDecimalsCheck();
    }
    /**
     * Check if cURL is available on the system
     *
     * @since 1.0
     */
    public function doCurlCheck(): void
    {
        if (!\extension_loaded('curl')) {
            $this->add_admin_error(\sprintf(
                // translators: %s: URL to the PHP cURL extension documentation.
                \__('Error: Please enable <a target="_blank" href="%s">cURL extension</a> in PHP.', 'virement-maitrise'),
                "https://www.php.net/manual/en/book.curl.php"
            ));
        }
    }
    /**
     * Check if OpenSSL is available on the system
     *
     * @since 2.2
     */
    public function doOpensslCheck(): void
    {
        if (!\extension_loaded('openssl')) {
            $this->add_admin_error(\sprintf(
                // translators: %s: URL to the PHP OpenSSL extension documentation.
                \__('Error: Please enable <a target="_blank" href="%s">OpenSSL extension</a> in PHP.', 'virement-maitrise'),
                "https://www.php.net/manual/fr/book.openssl.php"
            ));
        }
    }
    /**
     * Check if the 'plain' option is used in permalinks settings
     *
     * @since 2.2
     */
    public function doPermalinksStructureCheck(): void
    {
        if (empty(\get_option('permalink_structure'))) {
            $this->add_admin_error(\__('Error: Payments are not compatible with \'Plain\' permalink structure. You could instead use the \'Post name\' option, for example.', 'virement-maitrise'));
        }
    }
    /**
     * Check the number of decimals used for prices
     *
     * @since 2.3
     */
    public function doPriceDecimalsCheck(): void
    {
        $decimals = \wc_get_price_decimals();
        if ($decimals && $decimals !== 2) {
            $this->add_admin_error(\__('Your price precision is different than two decimals. During paying of orders, we will round prices to two decimals.', 'virement-maitrise'), 'warning');
        }
    }
    /**
     * Init PIS Client
     *
     * @return void
     * @since 3.0
     */
    private function initPisClient(): void
    {
        $wpContentDir = $wpContentDir = \WP_CONTENT_DIR . '/';
        $environments = ['sandbox', 'production'];
        $currentEnv = $this->environment ? 'sandbox' : 'production';
        $isWooCommerce = \is_checkout() || \wp_doing_ajax();
        $isWebhook = \strpos($_SERVER['REQUEST_URI'], 'wc-api/fintecture_webhook') !== \false;
        foreach ($environments as $environment) {
            // Don't create more than one pisclient on front & in webhook
            if (($isWooCommerce || $isWebhook) && $currentEnv !== $environment) {
                continue;
            }
            $appId = $this->getAppId($environment);
            $appSecret = $this->getAppSecret($environment);
            $privateKey = $this->getPrivateKey($environment);
            // Don't configure PISClient if we don't have all infos
            if (!$appId || !$appSecret || !$privateKey) {
                if (($appId || $appSecret || $privateKey) && $this->inFintectureSectionPage()) {
                    if ($environment === 'sandbox') {
                        \add_action('admin_notices', [$this, 'incompleteErrorSandbox']);
                    } else {
                        \add_action('admin_notices', [$this, 'incompleteErrorProduction']);
                    }
                }
                continue;
            }
            try {
                $this->pisClients[$environment] = new PisClient(['appId' => $appId, 'appSecret' => $appSecret, 'privateKey' => $privateKey, 'environment' => $environment, 'encryptionDir' => $wpContentDir]);
            } catch (\Exception $e) {
                fintectureWriteLog("Can't create  PISClient: " . $e->getMessage());
                if ($this->inFintectureSectionPage()) {
                    if ($environment === 'sandbox') {
                        \add_action('admin_notices', [$this, 'privateKeyErrorSandbox']);
                    } else {
                        \add_action('admin_notices', [$this, 'privateKeyErrorProduction']);
                    }
                } else {
                    return;
                }
            }
            if (isset($this->pisClients[$environment])) {
                // Get encrypted private key and check if we need to update CMS value
                $encryptedPrivateKey = $this->pisClients[$environment]->getEncryptedPrivateKey();
                if ($encryptedPrivateKey !== $privateKey) {
                    $option = $environment === 'sandbox' ? 'test_app_private_key' : 'app_private_key';
                    $this->update_option($option, $encryptedPrivateKey);
                }
            }
        }
    }
    /**
     * Returns PisClient depending of environment
     *
     * @param string $environment Environment
     * @param bool $generateToken Generate an access token
     * @param bool $log Log errors
     * @return PisClient|false
     * @since 1.0
     * @access private
     */
    private function getPisClient(string $environment = '', bool $generateToken = \true, bool $log = \true)
    {
        if (empty($environment)) {
            $environment = $this->environment ? 'sandbox' : 'production';
        }
        if (isset($this->pisClients[$environment])) {
            if ($generateToken) {
                $pisToken = $this->pisClients[$environment]->token->generate();
                if (!$pisToken->error) {
                    $this->pisClients[$environment]->setAccessToken($pisToken);
                    // set token of PIS client
                } else {
                    fintectureWriteLog("Can't generate an access token: " . $pisToken->errorMsg);
                    return \false;
                }
            }
            return $this->pisClients[$environment];
        }
        if ($log) {
            fintectureWriteLog('PisClient for "' . $environment . '" does not exists');
        }
        return \false;
    }
    /**
     * Returns APP ID depending of environment
     *
     * @param string $environment Environment
     * @return string
     * @since 1.0
     * @access private
     */
    private function getAppId(string $environment = ''): string
    {
        if (empty($environment)) {
            $environment = $this->environment ? 'sandbox' : 'production';
        }
        return $environment === 'sandbox' ? $this->testAppId : $this->appId;
    }
    /**
     * Returns APP secret depending of environment
     *
     * @param string $environment Environment
     * @return string
     * @since 1.0
     * @access private
     */
    private function getAppSecret(string $environment = ''): string
    {
        if (empty($environment)) {
            $environment = $this->environment ? 'sandbox' : 'production';
        }
        return $environment === 'sandbox' ? $this->testAppSecret : $this->appSecret;
    }
    /**
     * Returns a Private Key depending of environment
     *
     * @param string $environment Environment
     * @return string
     * @since 1.0
     * @access private
     */
    private function getPrivateKey(string $environment = ''): string
    {
        if (empty($environment)) {
            $environment = $this->environment ? 'sandbox' : 'production';
        }
        return $environment === 'sandbox' ? $this->testAppPrivateKey : $this->appPrivateKey;
    }
    /**
     * Plugin options, this basically defines the configuration form
     *
     * @since 1.0
     */
    public function init_form_fields(): void
    {
        $wc_statuses = \wc_get_order_statuses();
        $this->form_fields = \apply_filters('virement-maitrise_settings', ['module_settings_section' => ['title' => \__('Module settings', 'virement-maitrise'), 'type' => 'title'], 'info_message' => ['title' => \__('Explore our <a href="https://doc.virementmaitrise.societegenerale.eu/page/wordpress" target="_blank">online documentation</a> for step-by-step guidance on configuring this module. Need assistance? Contact our support team at support@virementmaitrise.societegenerale.eu.', 'virement-maitrise'), 'type' => 'title', 'class' => 'fintecture-notice notice notice-info'], 'enabled' => ['title' => \__('Enable/Disable', 'virement-maitrise'), 'label' => \__('Enable this payment gateway', 'virement-maitrise'), 'type' => 'checkbox', 'description' => \__('Enable this module to include the Virement Maitrisé.', 'virement-maitrise')], 'environment' => ['title' => \__('Environment', 'virement-maitrise'), 'id' => 'fintecture-environment', 'label' => \__('Enable test mode (sandbox)', 'virement-maitrise'), 'type' => 'checkbox', 'description' => \__('Switch to production mode to start accepting real payments.', 'virement-maitrise')], 'connection_settings_production_section' => ['title' => \__('Connection settings - PRODUCTION', 'virement-maitrise'), 'type' => 'title'], 'app_id' => ['title' => \__('APP ID', 'virement-maitrise'), 'id' => 'fintecture-app-id', 'type' => 'text', 'description' => \__('This is the APP ID provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise')], 'app_secret' => ['title' => \__('APP secret', 'virement-maitrise'), 'id' => 'fintecture-app-secret', 'type' => 'password', 'description' => \__('This is the APP secret provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise')], 'app_private_key' => ['title' => \__('Private key', 'virement-maitrise'), 'id' => 'fintecture-app-private-key', 'type' => 'file_input', 'description' => \__('This is the Private Key provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise'), 'value' => $this->appPrivateKey], 'test_production' => ['title' => \__('Check production credentials', 'virement-maitrise'), 'class' => 'fintecture-btn-test-js button-secondary', 'custom_attributes' => ['data-environment' => 'production'], 'type' => 'button', 'desc_tip' => \__('This allows you to verify your credentials.', 'virement-maitrise')], 'connection_settings_test_section' => ['title' => \__('Connection settings - TEST', 'virement-maitrise'), 'type' => 'title'], 'test_app_id' => ['title' => \__('Test (sandbox) APP ID', 'virement-maitrise'), 'id' => 'fintecture-test-app-id', 'type' => 'text', 'description' => \__('This is the APP ID provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise')], 'test_app_secret' => ['title' => \__('Test (sandbox) APP secret', 'virement-maitrise'), 'id' => 'fintecture-test-app-secret', 'type' => 'password', 'description' => \__('This is the APP secret provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise')], 'test_app_private_key' => ['title' => \__('Test (sandbox) private key', 'virement-maitrise'), 'id' => 'fintecture-test-app-private-key', 'type' => 'file_input', 'description' => \__('This is the private key provided to you when creating an application on Virement Maitrisé. <a href="https://console.virementmaitrise.societegenerale.eu/auth/register">Click here to create an account</a>', 'virement-maitrise'), 'value' => $this->testAppPrivateKey], 'test_sandbox' => ['title' => \__('Check test (sandbox) credentials', 'virement-maitrise'), 'class' => 'fintecture-btn-test-sandbox-js fintecture-btn-test-js button-secondary', 'custom_attributes' => ['data-environment' => 'sandbox'], 'type' => 'button', 'desc_tip' => \__('This allows you to verify your credentials.', 'virement-maitrise')], 'checkout_design_section' => ['title' => \__('Checkout design', 'virement-maitrise'), 'type' => 'title'], 'info_message_checkout' => ['title' => \__('Design may change depending on the version of woocommerce and wordpress you are using.', 'virement-maitrise'), 'type' => 'title', 'class' => 'fintecture-notice notice notice-info'], 'checkout_design_selection' => ['title' => \__('Checkout design', 'virement-maitrise'), 'id' => 'fintecture-checkout-design-selection', 'type' => 'checkout_design_selection', 'options' => ['it' => \__('Simplified Transfer', 'virement-maitrise'), 'it-st' => \__('Simplified Transfer and Classic Transfer', 'virement-maitrise')]], 'force_position' => ['title' => \__('First position', 'virement-maitrise'), 'id' => 'fintecture-force-position', 'label' => \__('Enable first position depending of cart amount', 'virement-maitrise'), 'type' => 'checkbox', 'description' => \__('Show Virement Maitrisé in first position at checkout.', 'virement-maitrise')], 'amount_force_position' => ['title' => \__('Minimal amount for first position', 'virement-maitrise'), 'id' => 'fintecture-amount-first-position', 'type' => 'number', 'description' => \__('Minimal cart amount to place Virement Maitrisé in first position (in €).', 'virement-maitrise')], 'recommend_it_payment_method' => ['title' => \__('"Recommended" badge', 'virement-maitrise'), 'id' => 'fintecture-recommend-it-payment-method', 'label' => \__('Recommend the payment method on checkout page', 'virement-maitrise'), 'type' => 'checkbox'], 'advanced_settings_section' => ['title' => \__('Advanced settings', 'virement-maitrise'), 'type' => 'title'], 'warning_message' => ['title' => \__('This section is intended for advanced users. Changing the settings may impact the proper functioning of your system.', 'virement-maitrise'), 'type' => 'title', 'class' => 'fintecture-notice notice notice-warning'], 'status_mapping_section' => ['title' => \__('Payment status mapping between Virement Maitrisé and WooCommerce', 'virement-maitrise'), 'type' => 'title', 'class' => 'fintecture-section-subtitle'], 'accepted_payment' => ['title' => \__('Accepted payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses], 'pending_payment' => ['title' => \__('Pending payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses], 'smart_transfer_pending_payment' => ['title' => \__('Pending payment (Classic Transfer)', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses, 'description' => \__('The transfer can take a business day to arrive. Use a status WooCommerce does not cancel automatically, such as On hold: an order left in Pending payment is cancelled once the "Hold stock" delay has passed.', 'virement-maitrise')], 'partial_payment' => ['title' => \__('Partial payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses], 'overpaid_payment' => ['title' => \__('Overpaid payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses], 'failed_payment' => ['title' => \__('Failed payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses], 'cancelled_payment' => ['title' => \__('Cancelled payment', 'virement-maitrise'), 'type' => 'select', 'options' => $wc_statuses]]);
    }
    /**
     * Generate Button HTML
     * https://docs.woocommerce.com/document/implementing-wc-integration/
     *
     * @param string $key
     * @param mixed $data
     * @return string|false
     */
    public function generate_button_html(string $key, $data)
    {
        $field = $this->plugin_id . $this->id . '_' . $key;
        $defaults = ['class' => 'button-secondary', 'css' => '', 'custom_attributes' => [], 'desc_tip' => \false, 'description' => '', 'title' => ''];
        $data = \wp_parse_args($data, $defaults);
        \ob_start();
        require 'custom_wc_inputs/button.php';
        return \ob_get_clean();
    }
    /**
     * Generate File Input HTML
     * https://docs.woocommerce.com/document/implementing-wc-integration/
     *
     * @param string $key
     * @param mixed $data
     * @return string|false
     */
    public function generate_file_input_html(string $key, $data)
    {
        $field = $this->plugin_id . $this->id . '_' . $key;
        $defaults = ['class' => '', 'css' => '', 'custom_attributes' => [], 'desc_tip' => \false, 'description' => '', 'value' => ''];
        $data = \wp_parse_args($data, $defaults);
        \ob_start();
        require 'custom_wc_inputs/file_input.php';
        return \ob_get_clean();
    }
    /**
     * Generate Checkout design selection input HTML
     * https://docs.woocommerce.com/document/implementing-wc-integration/
     *
     * @param string $key
     * @param mixed $data
     * @return string|false
     */
    public function generate_checkout_design_selection_html(string $key, $data)
    {
        $field = $this->plugin_id . $this->id . '_' . $key;
        $iso_code = \substr(get_locale(), 0, 2);
        $defaults = ['class' => '', 'css' => '', 'custom_attributes' => [], 'desc_tip' => \false, 'description' => '', 'options' => [], 'img_path' => \plugin_dir_url(__FILE__) . '../assets/img/', 'iso_code' => $iso_code];
        $data = \wp_parse_args($data, $defaults);
        $currentDesign = $this->get_option($key);
        \ob_start();
        require 'custom_wc_inputs/checkout_design_selection.php';
        return \ob_get_clean();
    }
    /**
     * Admin save
     */
    public function process_admin_options()
    {
        // Empty admin notices to avoid duplicates
        \remove_action('admin_notices', [$this, 'admin_notices_fintecture']);
        \remove_action('admin_notices', [$this, 'privateKeyErrorSandbox']);
        \remove_action('admin_notices', [$this, 'privateKeyErrorProduction']);
        \remove_action('admin_notices', [$this, 'incompleteErrorSandbox']);
        \remove_action('admin_notices', [$this, 'incompleteErrorProduction']);
        $prefix = 'woocommerce_wc_fintecture_gateway_';
        $isSandbox = isset($_POST[$prefix . 'environment']);
        if ($isSandbox) {
            $appId = $_POST[$prefix . 'test_app_id'] ?? '';
            $appSecret = $_POST[$prefix . 'test_app_secret'] ?? '';
        } else {
            $appId = $_POST[$prefix . 'app_id'] ?? '';
            $appSecret = $_POST[$prefix . 'app_id'] ?? '';
        }
        if (!$appId || !$appSecret) {
            if ($isSandbox) {
                \WC_Admin_Settings::add_error('Test mode (sandbox): please fill required fields');
            } else {
                \WC_Admin_Settings::add_error('Production: please fill required fields');
            }
            return \false;
        }
        $option1 = $prefix . 'app_private_key';
        // input file field 1
        $option2 = $prefix . 'test_app_private_key';
        // input file field 2
        $_POST[$option1] = $this->get_option('app_private_key');
        // default value for not loosing key at saving
        $_POST[$option2] = $this->get_option('test_app_private_key');
        // default value for not loosing key at saving
        if (!empty($_FILES)) {
            // if some files have been uploaded
            if (isset($_FILES[$option1]) && $this->checkUploadSuccess($_FILES[$option1])) {
                $appPrivateKey = \file_get_contents($_FILES[$option1]['tmp_name']);
                if (empty($appPrivateKey)) {
                    $this->add_settings_error(\__('Production Private Key not valid. Please verify your .pem file.', 'virement-maitrise'));
                }
                $_POST[$option1] = $appPrivateKey;
                // store the private key in the post var
            }
            if (isset($_FILES[$option2]) && $this->checkUploadSuccess($_FILES[$option2])) {
                $testAppPrivateKey = \file_get_contents($_FILES[$option2]['tmp_name']);
                if (empty($testAppPrivateKey)) {
                    $this->add_settings_error(\__('Test (sandbox) Private Key not valid. Please verify your .pem file.', 'virement-maitrise'));
                }
                $_POST[$option2] = $testAppPrivateKey;
                // store the test private key in the post var
            }
        }
        // Call the original method to save options (will read $this->get_post_data() again so that new POST values will be inside)
        parent::process_admin_options();
        try {
            Telemetry::logAction('save', fintectureSystemInfos());
        } catch (\Exception $e) {
            fintectureWriteLog("Can't send telemetry call: " . $e);
        }
        return \true;
    }
    /**
     * Check if upload has worked
     *
     * @param array<mixed> $file Uploaded file
     * @return bool
     */
    private function checkUploadSuccess(array $file): bool
    {
        $fileName = isset($file['name']) ? sanitize_file_name($file['name']) : '';
        if (!empty($fileName)) {
            $fileType = wp_check_filetype($fileName, ['pem' => 'application/x-pem-file']);
            if ($fileType['ext'] !== 'pem') {
                $this->add_settings_error(\__('App Private Key not valid: file must be a .pem file.', 'virement-maitrise'));
                return \false;
            }
            if ($file['error'] === \UPLOAD_ERR_OK) {
                return \true;
            } else {
                $this->add_settings_error(\sprintf(
                    // translators: %s: PHP file upload error code.
                    \__('App Private Key not uploaded: %s', 'virement-maitrise'),
                    $file['error']
                ));
            }
        }
        return \false;
    }
    /**
     * We are processing the payments here, if all is going well we change the order status to 'waiting payment' and redirect
     * to our payment gateway, if other case we update the order to fail.
     *
     * @param int $order_id
     * @return array<string,string>|void|WP_Error redirection to our payment gateway
     * @since 1.0
     */
    public function process_payment($order_id)
    {
        // 'success' instead of 'error' to allow redirection on checkout page
        $redirectToCheckoutWithError = ['result' => 'success', 'redirect' => $this->checkoutErrorUrl];
        // Verify permalink structure to avoid 404 error after connect redirection
        if (empty(\get_option('permalink_structure'))) {
            fintectureWriteLog("'Plain' option used for permalink structure. Not supported by WooCommerce API.");
            return $redirectToCheckoutWithError;
        }
        // Order checks
        $order = \wc_get_order($order_id);
        if (!$order || \is_bool($order)) {
            fintectureWriteLog('Payment failed: order not found');
            $error_message = \__("Order not found", 'virement-maitrise');
            return new \WP_Error('1', $error_message);
        } elseif (!\is_a($order, 'WC_Order')) {
            fintectureWriteLog('The order type is not WC_Order');
            $error_message = \__("Order invalid type", 'virement-maitrise');
            return new \WP_Error('1', $error_message);
        }
        if (0 >= $order->get_total()) {
            return $this->completeFreeOrder($order);
        }
        try {
            $order->update_status($this->pendingPayment, \__('Awaiting payment', 'virement-maitrise'));
            $payload = $this->getPayload($order);
            try {
                $state = Crypto::encodeToBase64(['order_id' => $order->get_id()]);
                $pisClient = $this->getPisClient();
                if (!$pisClient) {
                    return $redirectToCheckoutWithError;
                }
                $connect = $pisClient->connect->generate($payload, $state, null, \wc_get_checkout_url());
                if (!$connect->error) {
                    $session_id = $connect->meta->session_id;
                    /** @phpstan-ignore-line */
                    $order->set_transaction_id($session_id);
                    $order->save();
                    return ['result' => 'success', 'redirect' => $connect->meta->url];
                } else {
                    fintectureWriteLog('Error: ' . $connect->errorMsg);
                    return $redirectToCheckoutWithError;
                }
            } catch (\Exception $e) {
                fintectureWriteLog('Error: ' . $e->getMessage());
                return $redirectToCheckoutWithError;
            }
        } catch (\Exception $e) {
            $order->update_status($this->failedPayment);
            fintectureWriteLog('Error: ' . $e->getMessage());
            return $redirectToCheckoutWithError;
        }
    }
    /**
     * Completes an order without a positive value. We contemplate this case as a free payment
     *
     * @param mixed $order The order to complete
     * @return array<string> Redirection data for 'process_payment'
     * @since 1.0
     * @access private
     */
    private function completeFreeOrder($order): array
    {
        $order->payment_complete();
        /** @phpstan-ignore-next-line */
        get_wc_instance()->cart->empty_cart();
        // Remove cart
        // Return thank you page redirect.
        return ['result' => 'success', 'redirect' => $this->get_return_url($order)];
    }
    /**
     * Generates an array with the payload information
     *
     * @param mixed $order
     * @return array<string, array<string, array<string, string>|string>>
     * @since 1.0
     * @access private
     */
    private function getPayload($order): array
    {
        $total = $order->get_total();
        $total = \round($total, 2);
        // keep only 2 decimals
        $currencyCode = $order->get_currency();
        $billingFullName = $order->get_formatted_billing_full_name();
        $billingEmail = $order->get_billing_email();
        $billingPhone = $order->get_billing_phone();
        $psuAddressStreet = $order->get_billing_address_1();
        $psuAddressComplement = $order->get_billing_address_2();
        $psuAddressZip = $order->get_billing_postcode();
        $psuAddressCity = $order->get_billing_city();
        $psuAddressCountry = $order->get_billing_country();
        $psuCompany = $order->get_billing_company();
        return ['data' => ['type' => 'PAYMENT', 'attributes' => ['amount' => (string) $total, 'currency' => $currencyCode, 'communication' => \FINTECTURE_PAYMENT_PREFIX . $order->get_id() . '']], 'meta' => ['psu_name' => \sanitize_text_field($billingFullName), 'psu_email' => \sanitize_email($billingEmail), 'psu_ip' => $order->get_customer_ip_address(), 'psu_phone' => \sanitize_text_field($billingPhone), 'psu_company' => \sanitize_text_field($psuCompany), 'psu_address' => ['street' => \sanitize_text_field($psuAddressStreet), 'complement' => \sanitize_text_field($psuAddressComplement), 'zip' => \sanitize_text_field($psuAddressZip), 'city' => \sanitize_text_field($psuAddressCity), 'country' => \sanitize_text_field($psuAddressCountry)]]];
    }
    /**
     * After the payment, gateway returns to WooCommerce and executes this function.
     * This function evaluates if the payment was successful or not by checking the
     * params of the URL and checks if some parameter was changed to make a fraud
     * attempt by means a digest code verification
     *
     * @return array<string, string>|void
     * @since 1.0
     */
    public function post_payment()
    {
        [$order, $orderId, $sessionId] = fintecturePostPayment();
        if (!$order || !$orderId || !$sessionId) {
            $this->redirectCheckoutError();
        }
        $pisClient = $this->getPisClient();
        if ($pisClient) {
            $payment = $pisClient->payment->get($sessionId);
            if (!$payment->error) {
                /** @phpstan-ignore-next-line */
                $communicationMatch = $payment->data->attributes->communication === \FINTECTURE_PAYMENT_PREFIX . $orderId;
                /** @phpstan-ignore-next-line */
                $paymentStatus = $communicationMatch ? $payment->meta->status : 'payment_unsuccessful';
            }
        } else {
            fintectureWriteLog('Error: No PIS client');
        }
        if (!isset($paymentStatus)) {
            if (isset($payment)) {
                fintectureWriteLog('Error: ' . $payment->errorMsg);
            }
            $this->redirectCheckoutError();
        } elseif ($this->getOrderStatusWithWCPrefix($order) !== $this->pendingPayment) {
            if ($paymentStatus === 'payment_created' || $paymentStatus === 'payment_pending') {
                \wp_redirect($order->get_checkout_order_received_url() . '&status=' . $paymentStatus);
            } else {
                $this->redirectCheckoutError($paymentStatus);
            }
        } elseif ($paymentStatus === 'payment_created') {
            // Some notes to customer (replace true with false to make it private)
            $order->payment_complete($sessionId);
            get_wc_instance()->cart->empty_cart();
            /** @phpstan-ignore-line */
            $order->update_status($this->acceptedPayment);
            do_action('fintecture_payment_created', $orderId);
            $order->save();
            \wp_redirect($order->get_checkout_order_received_url() . '&status=' . $paymentStatus);
        } elseif (\in_array($paymentStatus, ['payment_unsuccessful', 'sca_required'], \true)) {
            $this->redirectCheckoutError($paymentStatus);
        } elseif ($paymentStatus === 'payment_pending') {
            get_wc_instance()->cart->empty_cart();
            /** @phpstan-ignore-line */
            /** @phpstan-ignore-next-line */
            $order->update_status($this->getPendingPaymentStatus($payment->meta->type ?? ''));
            $order->save();
            \wp_redirect($order->get_checkout_order_received_url() . '&status=' . $paymentStatus);
        } else {
            fintectureWriteLog('Failed payment for order: ' . $orderId);
            $order->update_status($this->failedPayment);
            $this->redirectCheckoutError($paymentStatus);
        }
        exit;
    }
    /**
     * A few moment after the payment, gateway returns to WooCommerce and executes this function
     * This function set the final order status to be sure to have the most up-to-date status
     */
    public function webhook(): void
    {
        if (!$this->validSignature()) {
            fintectureWriteLog('webhook - invalid_signature');
            \http_response_code(401);
            exit('invalid_signature');
        }
        $response = fintectureWebhook();
        if (!\in_array($response['params']['type'], self::ALLOWED_WEBHOOK_TYPES)) {
            exit('invalid_webhook_type');
        }
        $transferState = $response['params']['transfer_state'];
        $order = $response['order'];
        $status = $this->getOrderStatus($response['params']);
        if (!$order) {
            fintectureWriteLog('webhook - no_order');
            \http_response_code(400);
            exit('invalid_order');
        } elseif (!$status) {
            fintectureWriteLog('webhook - no_status');
            \http_response_code(400);
            exit('invalid_status');
        }
        if ($response['params']['type'] === 'ManualTransfer' && ($response['params']['status'] === 'payment_partial' && $transferState === 'insufficient' || $response['params']['status'] === 'payment_created' && $transferState === 'overpaid' || $response['params']['status'] === 'payment_created' && $transferState === 'received')) {
            $this->addOrderPayment($response['params'], $order);
        } elseif ($this->getOrderStatusWithWCPrefix($order) === $this->acceptedPayment) {
            // Check if the order has already been in the final status
            // If yes don't re-set it
            exit('status_already_final');
        } elseif ($this->getOrderStatusWithWCPrefix($order) === $status) {
            // Check if the state to set is the same as the current one
            // If yes don't re-set it
            exit('status_already_set');
        } elseif ($response['params']['status'] === 'payment_created') {
            $order->update_status($status);
            do_action('fintecture_payment_created', $order->get_id());
        } else {
            $order->update_status($status);
        }
        exit;
    }
    /**
     * Add WooCommerce prefix to order status
     * https://woocommerce.github.io/code-reference/classes/WC-Abstract-Order.html#method_get_status
     */
    public function getOrderStatusWithWCPrefix(\WC_Order $order): string
    {
        return 'wc-' . $order->get_status();
    }
    /**
     * Get Wordpress status associated with our payment status
     *
     * @param array{state: string, status: string, session_id: string, customer_id: string, provider: string, transfer_state: string, received_amount: float, type: string} $params
     *
     * @return null|string $status
     */
    public function getOrderStatus($params): ?string
    {
        // Mapping by payment_status
        $statusMapping = ['payment_created' => $this->acceptedPayment, 'payment_pending' => $this->getPendingPaymentStatus($params['type']), 'payment_error' => $this->cancelledPayment, 'payment_unsuccessful' => $this->failedPayment, 'payment_partial' => $this->partialPayment, 'payment_cancelled' => $this->cancelledPayment];
        // Mapping by transfer state
        if ($params['transfer_state'] === 'overpaid') {
            $statusMapping['payment_created'] = $this->overpaidPayment;
        }
        if (isset($statusMapping[$params['status']])) {
            return $statusMapping[$params['status']];
        }
        return null;
    }
    /**
     * A Smart Transfer is paid from the payer's bank, often a day later: its pending order
     * must not stay in a status that WooCommerce auto-cancels after "Hold stock" minutes.
     */
    private function getPendingPaymentStatus(string $paymentType): string
    {
        return $paymentType === 'ManualTransfer' ? $this->smartTransferPendingPayment : $this->pendingPayment;
    }
    /**
     * Endpoint for testing credentials
     */
    public function connection_test(): void
    {
        $privateKey = sanitize_textarea_field(wp_unslash($_POST['private_key'] ?? ''));
        $environment = sanitize_key(wp_unslash($_POST['environment'] ?? ''));
        if (!\in_array($environment, ['sandbox', 'production'], \true)) {
            \http_response_code(400);
            exit;
        }
        if (empty($privateKey)) {
            $pisClient = $this->getPisClient($environment, \false, \false);
            if ($pisClient) {
                $privateKey = $pisClient->getFinalPrivateKey();
            }
        }
        $appId = \sanitize_text_field(wp_unslash($_POST['app_id'] ?? ''));
        $appSecret = \sanitize_text_field(wp_unslash($_POST['app_secret'] ?? ''));
        if (!empty($appId) && !empty($appSecret) && !empty($privateKey)) {
            $response = Validation::validCredentials('pis', ['appId' => $appId, 'appSecret' => $appSecret, 'privateKey' => $privateKey], $environment);
            $code = $response ? 200 : 400;
        } else {
            $code = 400;
        }
        \http_response_code($code);
        exit;
    }
    /**
     * Endpoint to send checkout event
     */
    public function checkout_event(): void
    {
        $log = Telemetry::logAction('checkout', fintectureSystemInfos());
        $code = $log ? 200 : 400;
        \http_response_code($code);
        exit;
    }
    /**
     * Endpoint to send metric event (checkout dropdown)
     */
    public function dropdown_event(): void
    {
        $log = Telemetry::logMetric('custom-module-checkout-tooltip-displayed');
        $code = $log ? 200 : 400;
        \http_response_code($code);
        exit;
    }
    /**
     * Check if a signature is valid
     *
     * @return bool
     */
    private function validSignature(): bool
    {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw body required for cryptographic webhook signature verification
        $body = \file_get_contents('php://input');
        $digest = wp_unslash($_SERVER['HTTP_DIGEST'] ?? '');
        $signature = wp_unslash($_SERVER['HTTP_SIGNATURE'] ?? '');
        return Validation::validSignature($body, $digest, $signature);
    }
    /**
     * Return the gateway's icon.
     *
     * @return string
     */
    public function get_icon()
    {
        $icon = '<img src="' . esc_url(\plugin_dir_url(__FILE__) . '../assets/img/checkout/virementmaitrise.svg') . '" style="margin-top: 5px;" alt="' . \esc_attr($this->get_title()) . '">';
        return \apply_filters('woocommerce_gateway_icon', $icon, $this->id);
    }
    /**
     * Create the checkout template
     *
     * @return void
     */
    public function payment_fields()
    {
        $enabledForcePosition = \false;
        if ($this->forcePosition) {
            if (empty($this->amountForcePosition)) {
                $forcePositionAmount = 0;
            } else {
                $forcePositionAmount = $this->amountForcePosition;
            }
            /** @phpstan-ignore-next-line */
            $cart = get_wc_instance()->cart;
            $cartAmount = $cart->total;
            if ($cartAmount > $forcePositionAmount) {
                $enabledForcePosition = \true;
            }
        }
        $recommendText = \__('Recommended', 'virement-maitrise');
        $templateArgs = ['checkoutDesign' => $this->checkoutDesignSelection];
        /** @phpstan-ignore-next-line */
        $cartData = get_wc_instance()->session->get('cart');
        $cartId = \array_keys($cartData)[0] ?? 0;
        \wp_localize_script('wc_gateway_fintecture_old-checkout_js', 'virement_maitrise_vars', ['cartData' => $cartData, 'cartId' => $cartId, 'checkoutEventUrl' => \site_url('/wc-api/fintecture_checkout_event'), 'dropdownEventUrl' => \site_url('/wc-api/fintecture_dropdown_event'), 'forcePosition' => $enabledForcePosition, 'recommendItPaymentMethod' => $this->recommendItPaymentMethod, 'recommendText' => $recommendText]);
        \wc_get_template('checkout-description.php', $templateArgs, '', \plugin_dir_path(__FILE__) . '../views/');
    }
    /**
     * Redirect user to checkout page with a generic error
     */
    private function redirectCheckoutError(string $status = 'cms_internal_error'): void
    {
        \wp_safe_redirect(\wc_get_checkout_url() . '?status=' . $status);
        exit;
    }
    /**
     * @param array{state: string, status: string, session_id: string, customer_id: string, provider: string, transfer_state: string, received_amount: float, amount: float, last_transaction_amount: float} $params
     * @param WC_Order $order
     */
    private function addOrderPayment(array $params, $order): void
    {
        $orderTotal = \number_format($order->get_total(), 2);
        $orderReceivedAmount = \number_format($params['received_amount'], 2);
        $note = '';
        if ($params['status'] === 'payment_created') {
            if ($params['transfer_state'] === 'received') {
                if ($params['last_transaction_amount'] === $params['amount']) {
                    // translators: %1$s: amount received, %2$s: total order amount.
                    $note = \sprintf(\__('New payment. Order paid. %1$s € / %2$s €', 'virement-maitrise'), $orderReceivedAmount, $orderTotal);
                } else {
                    // translators: %1$s: amount received, %2$s: total order amount.
                    $note = \sprintf(\__('New partial payment. Order paid.  %1$s € / %2$s €', 'virement-maitrise'), $orderReceivedAmount, $orderTotal);
                }
                $order->update_status($this->acceptedPayment);
                do_action('fintecture_payment_created', $order->get_id());
            } elseif ($params['transfer_state'] === 'overpaid') {
                // translators: %1$s: amount received, %2$s: total order amount.
                $note = \sprintf(\__('New overpaid payment. %1$s € / %2$s €', 'virement-maitrise'), $orderReceivedAmount, $orderTotal);
                $order->update_status($this->acceptedPayment);
                $order->update_status($this->overpaidPayment);
                do_action('fintecture_payment_created', $order->get_id());
            }
        } elseif ($params['status'] === 'payment_partial') {
            // translators: %1$s: amount received, %2$s: total order amount.
            $note = \sprintf(\__('New partial payment. %1$s € / %2$s €', 'virement-maitrise'), $orderReceivedAmount, $orderTotal);
            $order->update_status($this->partialPayment);
        }
        $order->add_order_note($note, 0);
    }
    /**
     * @param int $orderId
     * @param null|float $amount
     * @param string $reason
     *
     * @return bool|WP_Error
     */
    public function process_refund($orderId, $amount = null, $reason = '')
    {
        if ($amount != null && $amount > 0) {
            $order = \wc_get_order($orderId);
            if (!$order || \is_bool($order)) {
                fintectureWriteLog("Can't refund the order : order not found.");
                $errorMessage = \__("Can't refund the order : order not found.", 'virement-maitrise');
                return new \WP_Error('1', $errorMessage);
            } elseif (!\is_a($order, 'WC_Order')) {
                fintectureWriteLog("Can't refund the order: order type is not WC_Order.");
                $errorMessage = \__("Can't refund the order: order type is not WC_Order.", 'virement-maitrise');
                return new \WP_Error('1', $errorMessage);
            } else {
                $sessionId = $order->get_transaction_id();
                $amount = (string) \round($amount, 2);
                return $this->sendRefund($sessionId, $amount, $order);
            }
        } else {
            fintectureWriteLog("Can't refund the order: amount of the refund must be superior to 0.");
            $errorMessage = \__("Can't refund the order: amount of the refund must be superior to 0.", 'virement-maitrise');
            return new \WP_Error('1', $errorMessage);
        }
    }
    /**
     * @param int $orderId
     * @param string $previousStatus
     * @param string $nextStatus
     *
     * @return void|bool|WP_Error
     */
    public function woocommerce_order_status_changed($orderId, $previousStatus, $nextStatus)
    {
        $order = \wc_get_order($orderId);
        if (!$order || \is_bool($order)) {
            fintectureWriteLog('Payment failed: order not found');
            $errorMessage = \__("Order not found", 'virement-maitrise');
            return new \WP_Error('1', $errorMessage);
        } elseif (!\is_a($order, 'WC_Order')) {
            fintectureWriteLog('The order type is not WC_Order');
            $errorMessage = \__("Order invalid type", 'virement-maitrise');
            return new \WP_Error('1', $errorMessage);
        }
        if ($order->get_payment_method() === $this->id) {
            $sessionId = $order->get_transaction_id();
            if ($nextStatus === 'refunded') {
                $orderRefunds = $order->get_refunds();
                if (\count($orderRefunds) > 0) {
                    $amount = (string) \round($orderRefunds[0]->amount, 2);
                    return $this->sendRefund($sessionId, $amount, $order);
                } else {
                    fintectureWriteLog("Can't refund the order: no refund found.");
                    $errorMessage = \__("Can't refund the order: no refund found.", 'virement-maitrise');
                    return new \WP_Error('1', $errorMessage);
                }
            } elseif ($nextStatus === 'cancelled') {
                return $this->cancelOrder($sessionId, $order);
            }
        }
    }
    /**
     * @param string $sessionId
     * @param string $amount
     * @param WC_Order $order
     *
     * @return bool|WP_Error
     */
    public function sendRefund($sessionId, $amount, $order)
    {
        $data = ['meta' => ['session_id' => $sessionId], 'data' => ['attributes' => ['amount' => $amount]]];
        $pisClient = $this->getPisClient();
        if ($pisClient) {
            $refundResponse = $pisClient->refund->generate($data);
            if (!$refundResponse->error) {
                $refundStatus = $refundResponse->result->meta->status ?? '';
            } else {
                $refundStatus = $refundResponse->result->errors[0]->code ?? '';
            }
            switch ($refundStatus) {
                case 'refund_accepted':
                    return \true;
                case 'refund_waiting':
                    // translators: %s: refund amount in euros.
                    $note = \sprintf(\__("You must proceed to the refund of %s € directly from the Virement Maitrisé console with this type of account.", 'virement-maitrise'), $amount);
                    $order->add_order_note($note, 0);
                    return \true;
                case 'refund_aborted':
                    $errorMessage = \__("An error has occurred during refund. Please check your account in the Virement Maitrisé console.", 'virement-maitrise');
                    return new \WP_Error('1', $errorMessage);
                default:
                    fintectureWriteLog("Can't refund the order: " . $refundResponse->errorMsg);
                    $errorMessage = \__("An error has occurred during refund. Please do it manually from the Virement Maitrisé console.", 'virement-maitrise');
                    return new \WP_Error('1', $errorMessage);
            }
        } else {
            fintectureWriteLog("Can't refund the order: PIS client not found.");
            $errorMessage = \__("Can't refund the order: PIS client not found.", 'virement-maitrise');
            return new \WP_Error('1', $errorMessage);
        }
    }
    /**
     * @param string $sessionId
     * @param WC_Order $order
     *
     * @return bool|WP_Error
     */
    public function cancelOrder($sessionId, $order)
    {
        $data = ['meta' => ['status' => 'payment_cancelled', 'origin' => 'cms']];
        $pisClient = $this->getPisClient();
        if ($pisClient) {
            $cancelResponse = $pisClient->payment->update($sessionId, $data);
            if (!$cancelResponse->error) {
                return \true;
            } else {
                fintectureWriteLog("An error has occurred during cancellation: " . $cancelResponse->errorMsg);
                $errorMessage = \__("An error has occurred during cancellation.", 'virement-maitrise');
                return new \WP_Error('1', $errorMessage);
            }
        } else {
            fintectureWriteLog("An error has occurred during cancellation: PIS client not found.");
            $errorMessage = \__("An error has occurred during cancellation: PIS client not found.", 'virement-maitrise');
            return new \WP_Error('1', $errorMessage);
        }
    }
    /**
     * @return void
     */
    public function before_checkout_form()
    {
        $status = isset($_GET['status']) ? \sanitize_text_field($_GET['status']) : '';
        if (empty($status)) {
            return;
        }
        $this->getOrderConfirmationMessage($status);
    }
    /**
     * @param int $order_id
     *
     * @return void
     */
    public function before_thankyou($order_id)
    {
        static $already_run = \false;
        if ($already_run) {
            return;
        }
        $already_run = \true;
        $status = isset($_GET['status']) ? \sanitize_text_field($_GET['status']) : '';
        if (empty($status)) {
            return;
        }
        $orderPaymentMethod = null;
        $order = \wc_get_order($order_id);
        if ($order && !\is_bool($order) && \is_a($order, 'WC_Order')) {
            $orderPaymentMethod = $order->get_payment_method();
        }
        if ($orderPaymentMethod !== $this->id) {
            return;
        }
        $this->getOrderConfirmationMessage($status);
    }
    /**
     * @param string $status
     *
     * @return void
     */
    public function getOrderConfirmationMessage($status)
    {
        \wp_enqueue_style('wc_gateway_fintecture_shop_css', \plugins_url('assets/css/shop.css', __DIR__));
        /** @var WP_Post|null $contactPage */
        $contactPage = \get_page_by_path('contact');
        $contactPageUrl = $contactPage ? get_permalink($contactPage->ID) : \get_home_url();
        $templateArgs = ['imgPath' => \plugin_dir_url(__FILE__) . '../assets/img/', 'status' => $status, 'contactPageUrl' => $contactPageUrl];
        \wc_get_template('order-confirmation-message.php', $templateArgs, '', \plugin_dir_path(__FILE__) . '../views/');
    }
}
\class_alias('FintectureWC\Fintecture_Post_Payment', 'Fintecture_Post_Payment', \false);
