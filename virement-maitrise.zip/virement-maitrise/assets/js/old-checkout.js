if(!document.querySelector('.wp-block-woocommerce-checkout')) {
    window.addEventListener('load', function () {
        if (window.isLoaded) {
            return;
        }
        window.isLoaded = true;

        const cartId = virement_maitrise_vars.cartId;
        let storedCartId = localStorage.getItem('fintecture-cartId');
        if (!storedCartId || cartId !== storedCartId) {
            const checkoutSection = document.querySelector('.payment_method_wc_fintecture_gateway');
            if (checkoutSection) {
                var oReq = new XMLHttpRequest();
                oReq.open('get', virement_maitrise_vars.checkoutEventUrl, true);
                oReq.send();
            }
            localStorage.removeItem('fintecture-cartId');
            localStorage.setItem('fintecture-cartId', cartId);
        }

        document.addEventListener('click', function (e) {
            if (e.target && e.target.id == 'f-wc-dropdown-text' ||
                e.target.parentNode && e.target.parentNode.id == 'f-wc-dropdown-text' ||
                e.target.parentNode && e.target.parentNode.id == 'f-wc-howto') {
                const dropdown = document.getElementById('f-wc-dropdown');
                dropdown.classList.toggle('open');

                if (!sessionStorage.alreadyOpened) {
                    var oReqMetric = new XMLHttpRequest();
                    oReqMetric.open('get', virement_maitrise_vars.dropdownEventUrl, true);
                    oReqMetric.send();
                    sessionStorage.alreadyOpened = 'true'; // data in sessionStorage is cleared when the page session ends.
                }
            }
        });

        if (virement_maitrise_vars.forcePosition) {
            forcePosition();
        }
    });

    if (virement_maitrise_vars.forcePosition) {
        jQuery('body').on("update_checkout updated_checkout", function (e) {
            forcePosition();
        });

        function forcePosition() {
            const checkoutContainer = document.querySelector('.wc_payment_methods');
            const fintecturePaymentOption = document.querySelector('.payment_method_wc_fintecture_gateway');

            if (checkoutContainer) {
                checkoutContainer.prepend(fintecturePaymentOption);
            }
        }
    }

    if (virement_maitrise_vars.recommendItPaymentMethod) {
        jQuery('body').on("update_checkout updated_checkout", function (e) {
            if (!document.querySelector(".fintecture-badge")) {
                const fintecturePaymentOptionLabel = document.querySelector('.payment_method_wc_fintecture_gateway>label');
                if (fintecturePaymentOptionLabel) {
                    const textBadge = virement_maitrise_vars.recommendText;
                    const recommendBadge = document.createElement("span");
                    recommendBadge.className = "fintecture-badge";
                    const recommendBadgeText = document.createTextNode(textBadge);
                    recommendBadge.appendChild(recommendBadgeText);
                    fintecturePaymentOptionLabel.appendChild(recommendBadge);
                }
            }
        });
    }
}