const settings = window.wc.wcSettings.getSetting('wc_fintecture_gateway_data', {});
const label = window.wp.htmlEntities.decodeEntities(settings.title) || window.wp.i18n.__('Virement maitrisé', 'virement-maitrise');

const Label = () => {
    var icon = React.createElement('img', {
		src: settings.assetsUrl + 'checkout/virementmaitrise.svg',
		style: {
			display: 'inline',
			marginLeft: '5px',
            height: 'auto'
		},
	});

    if(settings.recommendedBadge && settings.recommendedText) {
        var recommendedBadge = React.createElement('span', {
            className: 'fintecture-badge',
            style: {
                display: 'inline',
                marginLeft: '10px',
            },
        }, settings.recommendedText);
    }

	return React.createElement('span', {
		className: 'wc-block-components-payment-method-label wc-block-components-payment-method-label--with-icon',
	}, label, icon, recommendedBadge);
}

var Content = () => {
    let src;
    if (window.innerWidth > 768) {
        src = settings.assetsUrl + 'admin/checkout_design/'+settings.checkoutDesign+'_payment_method_description_'+settings.isoCode+'_soc-gen.svg';
    } else {
        src = settings.assetsUrl + 'admin/checkout_design/'+settings.checkoutDesign+'_mobile_payment_method_description_'+settings.isoCode+'_soc-gen.svg';
    }

    return React.createElement('div', null,
        React.createElement('img', {
            src: src,
            style: {
                marginBottom: '5px'
            },
        })
    );
}

const Block_Gateway = {
    name: 'wc_fintecture_gateway',
    label: React.createElement(Label, null),
    content: React.createElement(Content, null),
    edit: React.createElement(Content, null),
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports,
    }
};
window.wc.wcBlocksRegistry.registerPaymentMethod(Block_Gateway);

window.addEventListener('load', function () {
    if (settings.enabledForcePosition) {
        // Find the content block of the payment method
        const checkoutContainer = document.getElementById('radio-control-wc-payment-method-options-wc_fintecture_gateway').closest('.wc-block-components-radio-control');
        // Find the Fintecture payment block
        const fintecturePaymentOption = document.getElementById('radio-control-wc-payment-method-options-wc_fintecture_gateway').closest('.wc-block-components-radio-control-accordion-option');

        if (checkoutContainer) {
            checkoutContainer.prepend(fintecturePaymentOption);
        }
    }
});