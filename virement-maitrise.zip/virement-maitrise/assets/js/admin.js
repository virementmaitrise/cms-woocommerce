window.addEventListener('load', function () {
    const idPrefix = 'woocommerce_wc_fintecture_gateway_';
    const successIcon = '<span class="dashicons dashicons-yes"></span>';
    const errorIcon = '<span class="dashicons dashicons-no"></span>';

    // Connection test
    document.querySelectorAll('.fintecture-btn-test-js').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            const environment = e.target.dataset.environment;
            const environmentId = environment === 'production' ? '' : 'test_';
            const app_id = document.querySelector('#' + idPrefix + environmentId + 'app_id').value;
            const app_secret = document.querySelector('#' + idPrefix + environmentId + 'app_secret').value;
            const private_key_file = document.querySelector('#' + idPrefix + environmentId + 'app_private_key');
            let private_key = '';
            
            // Read uploaded file if defined
            if (private_key_file && private_key_file.files && private_key_file.files[0]) {
                readFile(private_key_file.files[0], function (e) {
                    private_key = e.target.result;
                    makeRequest(app_id, app_secret, private_key, environment);
                });
            } else {
                makeRequest(app_id, app_secret, private_key, environment);
            }
        });
    });

    function makeRequest(app_id, app_secret, private_key, environment) {
        const data = new FormData();
        data.append('app_id', app_id);
        data.append('app_secret', app_secret);
        data.append('private_key', private_key);
        data.append('environment', environment);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', virement_maitrise_vars.connection_test_url);
        xhr.onload = function () {
            if (xhr.status === 200) {
                writeResponse('success', environment);
            } else {
                writeResponse('failure', environment);
            }
        };
        xhr.send(data);
    }

    function writeResponse(status, environment) {
        document.querySelectorAll('.test-result-js').forEach(function (element) {
            element.parentNode.removeChild(element);
        });
        
        let parentResultElement = '';
        let resultElement = '';
        let container = document.createElement('p');
        container.classList.add('test-result-js');
        
        const testButton = document.querySelector('.fintecture-btn-test-js[data-environment="' + environment + '"]');

        testButton.parentElement.appendChild(container);
        parentResultElement = testButton.parentElement;
        resultElement = parentResultElement.querySelector('.test-result-js');

        resultElement.classList.add(status === 'success' ? 'fintecture-success' : 'fintecture-error');
        resultElement.innerHTML = (status === 'success' ? successIcon + virement_maitrise_vars.success : errorIcon + virement_maitrise_vars.failed);
    }
    
    // Function to read content of a file
    function readFile(file, onLoadCallback) {
        const reader = new FileReader();
        reader.onload = onLoadCallback;
        reader.readAsText(file);
    }

    // Checkout design selection
    const checkoutDesignSelector = document.querySelectorAll('input[name="woocommerce_wc_fintecture_gateway_checkout_design_selection"]');

    if (checkoutDesignSelector.length > 0) {
        const checkoutDesignSelected = document.querySelector('input[name="woocommerce_wc_fintecture_gateway_checkout_design_selection"]:checked');
        const checkoutDesign1SubOptions = document.querySelector('#woocommerce_wc_fintecture_gateway_checkout_design_it_suboptions');
        const checkoutDesign2SubOptions = document.querySelector('#woocommerce_wc_fintecture_gateway_checkout_design_it-st_img');

        
        if (checkoutDesignSelected.value === 'it') {
            checkoutDesign1SubOptions.style.display = 'block';
            checkoutDesign2SubOptions.style.display = 'none';
        } else if (checkoutDesignSelected.value === 'it-st') {
            checkoutDesign1SubOptions.style.display = 'none';
            checkoutDesign2SubOptions.style.display = 'block';
        }

        checkoutDesignSelector.forEach(function (element) {
            element.addEventListener('change', function () {
                if (this.value === 'it') {
                    checkoutDesign1SubOptions.style.display = 'block';
                    checkoutDesign2SubOptions.style.display = 'none';
                } else if (this.value === 'it-st') {
                    checkoutDesign1SubOptions.style.display = 'none';
                    checkoutDesign2SubOptions.style.display = 'block';
                }
            });
        });
    }
});