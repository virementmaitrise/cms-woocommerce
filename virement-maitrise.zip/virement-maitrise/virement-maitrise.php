<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.virementmaitrise.societegenerale.eu/
 * @since             1.0
 * @package           SG_Gateway
 *
 * @wordpress-plugin
 * Plugin Name:       Virement Maitrisé
 * Requires Plugins:  woocommerce
 * Description:       Extends WooCommerce by enabling users to pay securely and directly from their bank account
 * Version:           3.10.8
 * Author:            Virement Maitrisé
 * Author URI:        https://www.fintecture.com/
 * License:           GPLv3
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 * Requires PHP: 7.2
 * Requires at least: 5.0
 * WC requires at least: 3.9
 * WC tested up to: 10.3
 */
require_once \plugin_dir_path(__FILE__) . 'includes/fix-for-php-scoper.php';
require_once \plugin_dir_path(__FILE__) . 'includes/constants.php';
require_once \plugin_dir_path(__FILE__) . 'includes/stats.php';
require_once \plugin_dir_path(__FILE__) . 'includes/logger.php';
require_once \plugin_dir_path(__FILE__) . 'includes/post-payment-validator.php';
require_once \plugin_dir_path(__FILE__) . 'includes/webhook.php';
require_once \plugin_dir_path(__FILE__) . 'vendor/scoper-autoload.php';
use FintectureWC\Fintecture\Config\Telemetry;
if (!defined('ABSPATH')) {
    exit;
}
\register_activation_hook(__FILE__, [__NAMESPACE__ . '\WC_Fintecture_Main', 'install']);
\register_deactivation_hook(__FILE__, [__NAMESPACE__ . '\WC_Fintecture_Main', 'disable']);
\register_uninstall_hook(__FILE__, [__NAMESPACE__ . '\WC_Fintecture_Main', 'uninstall']);
\add_action('plugins_loaded', [__NAMESPACE__ . '\WC_Fintecture_Main', 'get_instance'], 0);
if (!\class_exists('FintectureWC\WC_Fintecture_Main')) {
    class WC_Fintecture_Main
    {
        /**
         * Instance of the current class, null before first usage.
         *
         * @var WC_Fintecture_Main
         */
        protected static $instance = null;
        /**
         * Class constructor
         * @since 0.1
         */
        protected function __construct()
        {
            // Core class
            require_once \plugin_dir_path(__FILE__) . 'includes/class-wc-virement-maitrise.php';
        }
        /**
         * Install procedure
         *
         * @return void|false
         * @static
         * @since 2.3
         */
        public static function install()
        {
            if (!\current_user_can('activate_plugins')) {
                return \false;
            }
            try {
                Telemetry::logAction('install', fintectureSystemInfos());
            } catch (\Exception $e) {
                fintectureWriteLog("Can't send telemetry call: " . $e);
            }
        }
        /**
         * Disable procedure
         *
         * @return void|false
         * @static
         * @since 2.3
         */
        public static function disable()
        {
            if (!\current_user_can('activate_plugins')) {
                return \false;
            }
            try {
                Telemetry::logAction('disable', fintectureSystemInfos());
            } catch (\Exception $e) {
                fintectureWriteLog("Can't send telemetry call: " . $e);
            }
        }
        /**
         * Uninstallation procedure
         *
         * @return void|false
         * @static
         * @since 2.3
         */
        public static function uninstall()
        {
            if (!\current_user_can('activate_plugins')) {
                return \false;
            }
            try {
                Telemetry::logAction('uninstall', fintectureSystemInfos());
            } catch (\Exception $e) {
                fintectureWriteLog("Can't send telemetry call: " . $e);
            }
        }
        /**
         * Return class instance
         *
         * @static
         * @since 2.3
         * @return WC_Fintecture_Main
         */
        public static function get_instance()
        {
            /** @phpstan-ignore-next-line */
            if (\is_null(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }
        /**
         * Cloning is forbidden
         *
         * @since 2.3
         */
        public function __clone()
        {
            /** @phpstan-ignore-next-line */
            return \wp_die('Cloning is forbidden!');
        }
    }
    \class_alias('FintectureWC\WC_Fintecture_Main', 'WC_Fintecture_Main', \false);
}
/**
 * This action hook registers our PHP class as a WooCommerce payment gateway
 *
 * @param array<mixed> $gateways
 * @return array<mixed>
 */
function fintecture_add_gateway_class($gateways)
{
    $gateways[] = __NAMESPACE__ . '\Fintecture_Post_Payment';
    // class name of gateway
    return $gateways;
}
\add_filter('woocommerce_payment_gateways', __NAMESPACE__ . '\fintecture_add_gateway_class');
/**
 * This action hook permit to add a 'Settings' link inside plugin section
 *
 * @param array<mixed> $links
 * @return array<mixed>
 */
function fintecture_action_links($links)
{
    $pluginLinks = ['<a href="' . \admin_url('admin.php?page=wc-settings&tab=checkout') . '">' . \__('Settings', 'virement-maitrise') . '</a>'];
    return \array_merge($pluginLinks, $links);
    // Merge our new link with the default ones
}
\add_filter('plugin_action_links_' . \plugin_basename(__FILE__), __NAMESPACE__ . '\fintecture_action_links');
function register_fintecture_order_status(): void
{
    $fintectureCustomStates = [[
        'id_name' => 'wc-ftc-partial',
        'label' => \__('Partial payment (Virement Maitrisé)', 'virement-maitrise'),
        // translators: %s: order count.
        'label_count' => _n_noop('Partial payment (Virement Maitrisé) (%s)', 'Partial payment (Virement Maitrisé) (%s)', 'virement-maitrise'),
    ], [
        'id_name' => 'wc-ftc-overpaid',
        'label' => \__('Overpaid payment (Virement Maitrisé)', 'virement-maitrise'),
        // translators: %s: order count.
        'label_count' => _n_noop('Overpaid payment (Virement Maitrisé) (%s)', 'Overpaid payment (Virement Maitrisé) (%s)', 'virement-maitrise'),
    ]];
    foreach ($fintectureCustomStates as $customState) {
        register_post_status($customState['id_name'], ['label' => $customState['label'], 'public' => \true, 'show_in_admin_status_list' => \true, 'show_in_admin_all_list' => \true, 'exclude_from_search' => \false, 'label_count' => $customState['label_count']]);
    }
}
\add_action('init', __NAMESPACE__ . '\register_fintecture_order_status');
/**
 * Add custom status to order status list
 *
 * @param array<string, string> $orderStatuses
 * @return array<string, string>
 */
function add_fintecture_status_to_order_statuses(array $orderStatuses): array
{
    $newOrderStatuses = ['wc-ftc-partial' => \__('Partial payment (Virement Maitrisé)', 'virement-maitrise'), 'wc-ftc-overpaid' => \__('Overpaid payment (Virement Maitrisé)', 'virement-maitrise')];
    return \array_merge($orderStatuses, $newOrderStatuses);
}
\add_filter('wc_order_statuses', __NAMESPACE__ . '\add_fintecture_status_to_order_statuses');
// Custom function to declare compatibility with custom_order_tables and cart_checkout_blocks features
function fintecture_declare_cart_checkout_blocks_compatibility(): void
{
    if (\class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, \true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, \true);
    }
}
\add_action('before_woocommerce_init', __NAMESPACE__ . '\fintecture_declare_cart_checkout_blocks_compatibility');
// Hook a custom function to the 'woocommerce_blocks_loaded' action
\add_action('woocommerce_blocks_loaded', __NAMESPACE__ . '\register_fintecture_payment_method_type');
function register_fintecture_payment_method_type(): void
{
    if (\class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        require_once __DIR__ . '/includes/blocks/class-wc-fintecture-block-support.php';
        \add_action('woocommerce_blocks_payment_method_type_registration', function (\Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            $payment_method_registry->register(new Fintecture_Blocks());
        });
    }
}
