=== Virement Maitrisé ===
Contributors: anjansom, araluce, hugoposnic, quentinfintecture, virementmaitrise
Tags: soge, Payments, checkout, payment, bank
Requires PHP: 7.2
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 3.10.7
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

Payment by instant transfer allows your customers to pay instantly and securely from their bank account.

== Description ==

= In short =

Payment by Simplified Transfer allows your customers to pay you instantly from their bank account. You receive immediate confirmation and the payment is irrevocable.

= The advantages of this product =

Offer an adapted payment to your customers.

Easily add the solution to your cash register and start accepting payments by instant transfer, simply and without any setup costs!
(No need to change your payment provider)
 
Collect payments without limit!
 
Protect your income against fraud: the payment is non-cancellable and non-changeable.
 
Increase your conversion rates by 15%: no more illegitimate rejections due to the multiplication of intermediaries.
 
Reduce your transaction fees by 40% and only pay commissions when you receive a payment.

= What your customers will like =

* **Simplicity:** no need to create a Société Générale account, they connect directly to their online bank with the usual login details:
 * **Without entering an IBAN**
 * **Without adding a trusted beneficiary**
 * **No additional cost** 

* **Security:** no sensitive information is collected by either Société Générale or the merchants.

* **Rapid reimbursement:** they are refunded within 1 working day.

* **Reliability:** they can pay for large baskets without using their credit card limits.

= Specifications = 

**Easy and Simple** 

Online payment has never been easier:

* At checkout, your customer chooses the payment method "Virement maitrisé"
* He selects his bank
* He connects with his usual identifiers
* He confirms the payment pre-filled for him

**Immediate confirmation of payment**

* When the customer pays by "Simplified Transfer", you receive instant confirmation of the payment and the reconciliation is done immediately with WordPress as when the buyer pays by card.

**No more rejects!**

Société Générale allows you to collect money directly from your customer's account. No middlemen. No friction. No rejections, unlike credit cards where 15% of transactions are rejected even though the buyer has sufficient funds.

**Maximum security**

* Your customer does not transmit their personal bank details to the merchant or Société Générale. They authenticate themselves directly with their bank.

**No chargeback** 

* The Société Générale instant transfer payment protects merchants: your customer cannot cancel or change his payment.

**Pricing per transaction** 

* Pay 40% less commission than your current commissions
* No fixed costs
* No hidden fees

**Cash in quickly!**

* Depending on your customers' banks, you receive the money in your bank account between 10 seconds and 1 working day!

**Facilitate your bank reconciliation**

* Each payment is paid in full into your bank account.
* Each payment includes the transaction number associated with the sale
* Do your bank reconciliation in the blink of an eye

**Monthly billing**

* You will receive an invoice at the end of the month with the total amount of commissions on transactions made by payments by "Virement maitrisé".

**Legal provisions** 

This module is compliant with the European Data Protection Regulation (RGPD).

Société Générale is a payment institution supervised by the Banque de France and the ACPR under the N°56741.

**Languages**

* French
* English
* Spanish

= Video =

https://youtu.be/2uD_dupfBys

== Installation ==

Find and install the Virement Maitrisé plugin by following these steps:

1. Go to your WordPress administration portal
2. Extensions -> Search for extensions
3. In the search field, type "Société Générale" and press Enter
4. Once you have found the extension, press "Install", wait a few seconds, then press "Activate".
5. Your extension is installed and ready to be configured! Congratulations!
6. Go to WooCommerce -> Settings -> Payments -> Virement Maitrisé to configure the extension!


== Frequently Asked Questions ==

= Who can I contact if I have questions =

To contact us, go to the website: https://www.virementmaitrise.societegenerale.eu/

== Screenshots ==

1. The customer chooses 'Virement maitrisé'.
2. The customer selects his bank.
3. The customer enters their online bank details.
4. The customer confirms the payment.

== Changelog ==

= 3.10.7 =
- New status mapping for pending Classic Transfer payments, default On hold, so WooCommerce no longer cancels orders waiting for the transfer
- Internal fixes

= 3.10.6 =
- Internal fixes

= 3.10.5 =
- Tested up to WordPress 6.9
- Tested up to WooCommerce 10.3

= 3.10.4 =
- Tested up to WordPress 6.8
- Tested up to WooCommerce 9.7

= 3.10.3 =
- Internal fix

= 3.10.2 =
- Tested up to WordPress 6.7
- Tested up to WooCommerce 9.3

= 3.10.1 =
- Fix potential error on a function name

= 3.10.0 =
- Tested up to WordPress 6.6
- Tested up to WooCommerce 9.1
- Added support for Checkout Blocks on Woocommerce

= 3.9.3 =
- Take cancelled status sent by webhook in consideration 

= 3.9.2 =
- Fintecture SDK update to handle rare key encryption issue

= 3.9.1 =
- Tested up to WordPress 6.5
- Tested up to WooCommerce 8.7
- Add a link to our online CMS documentation
- Take more refund errors in consideration

= 3.9.0 =
- Add a message to ask if private key has been saved when connection test is failing

= 3.8.6 =
- Tested up to WooCommerce 8.5

= 3.8.5 =
- Put JS and CSS in dedicated files to fix inline formatting issues

= 3.8.4 =
- Fix a potential PHP warning

= 3.8.3 =
- Add an extra check for redirection replays

= 3.8.2 =
- Tested up to WordPress 6.4
- Update error messages on checkout page
- Update payment confirmation messages on validation page

= 3.8.1 =
- Fix a typo for the "recommended" badge

= 3.8.0 =
- Improve webhooks handling
- Change the payment method label on the checkout page
- Tested up to WooCommerce 8.1

= 3.7.0 =
- Add compatibility with HPOS (High Performance Order Storage)
- Tested up to WooCommerce 8.0

= 3.6.2 =
- Fix order confirmation page

= 3.6.1 =
- Tested up to WordPress 6.3
- Tested up to WooCommerce 7.9

= 3.6.0 =
- Add an optional recommended badge on checkout payment method

= 3.5.1 =
- Fix rounding of refund amounts

= 3.5.0 =
- Add a checkout design selection feature in the module configuration page
- Tested up to WooCommerce 7.7

= 3.4.0 =
- Add an option to move Fintecture at top of payment methods depending of a configurable cart amount
- Support refund directly from your orders
- Permit to cancel a Fintecture payment (for Manual Transfer) by cancelling an order
- Add a status mapping feature in the module configuration page
- Add sections in module configuration page
- Tested-up to WP 6.2 and WC 7.6

= 3.3.0 =
Tested up to WooCommerce 7.4
Support partial and overpaid payment status
Improve theme compatibility
Bump dependencies

= 3.2.5 =
Tested up to WooCommerce 7.1
Bump dependencies

= 3.2.4 =
Fix Fintecture dropdown not always shown
Tested up to WooCommerce 6.9
Bump dependencies

= 3.2.3 =
Tested up to WooCommerce 6.8
Bump dependencies

= 3.2.2 =
Tested up to WordPress 6.0
Tested up to WooCommerce 6.5

= 3.2.1 =
Force hiding of script and style elements on Fintecture checkout

= 3.2.0 =
Bump PHP requirement to 7.2
Tested up to WooCommerce 6.4

= 3.1.6 =
Tested up to WooCommerce 6.3

= 3.1.5 =
Fix an incompatibility with one other payment plugin

= 3.1.4 =
Tested up to WooCommerce 6.2

= 3.1.3 =
Tested up to WooCommerce 6.1
Replace a deprecated call

= 3.1.2 =
Tested up to WooCommerce 6.0
Some internal updates

= 3.1.1 =
Tested up to WooCommerce 5.9

= 3.1 =
New checkout design
Improve handling of payment errors
Improve PHP 7.1 compatibility

= 3.0.2 =
Update requirements checking

= 3.0.1 =
Small internal fix

= 3.0 =
Bump requirements
Rewrite using our new PHP SDK
Fix duplicates messages on saving of options
Load admin css only in our plugin page
Always show 'Fintecture - ' prefix in logs, errors and warnings

= 2.3.2 =
Load frontend css only on checkout
Improve translations

= 2.3.1 =
Fix spelling mistakes
Tested up to WordPress 5.8

= 2.3 =
Fix spelling mistakes
Check price precision and warn the the merchant if needed
Improve "test connection" flow

= 2.2 =
Add 'test credentials' buttons to config page
Upload buttons instead of text fields for private keys
Better requirements check
Improve security
Various fixes
Translation updates

= 2.1 =
Supports B2B

= 2.0 =
Changing checkout look & feel

= 1.7 =
Redirection URL provided by client configuration

= 1.6 =
Payment icon styles

= 1.5 =
New payment validation algorithm
New payment validation flow
New final redirection page

= 1.4 =
Preparing to load the payment

= 1.3 =
Added icon styles for the Fintecture payment method

= 1.2 =
Added icons and changed the default order status to "Payment Pending"

= 1.1 =
This version allows bank transfers