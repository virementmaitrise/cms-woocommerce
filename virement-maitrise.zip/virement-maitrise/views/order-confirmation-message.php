<?php

namespace FintectureWC;

if (!defined('ABSPATH')) {
    exit;
}
if ($status === 'payment_created') {
    ?>
    <div class="fintecture-alert fintecture-alert-success">
        <img src="<?php 
    echo esc_url($imgPath);
    ?>checkout/success.svg"/>
         <p><?php 
    echo esc_html(\__('Your payment with Virement Maitrisé has been successfully processed!', 'virement-maitrise'));
    ?></p>
    </div>
<?php 
} elseif ($status === 'payment_pending') {
    ?>
    <div class="fintecture-alert fintecture-alert-info">
        <img src="<?php 
    echo esc_url($imgPath);
    ?>checkout/info.svg"/>
         <p><?php 
    echo esc_html(\__('Your payment with Virement Maitrisé is currently being processed by your bank. You can track the status of your payment using the link provided in the confirmation email.', 'virement-maitrise'));
    ?></p>
    </div>
<?php 
} elseif ($status === 'payment_unsuccessful') {
    ?>
    <div class="fintecture-alert fintecture-alert-danger">
        <img src="<?php 
    echo esc_url($imgPath);
    ?>checkout/error.svg"/>
         <p><?php 
    echo esc_html(\__('The payment has failed. Please select another bank or another payment method.', 'virement-maitrise'));
    ?></p>
    </div>
<?php 
} elseif ($status === 'sca_required') {
    ?>
    <div class="fintecture-alert fintecture-alert-warning">
        <img src="<?php 
    echo esc_url($imgPath);
    ?>checkout/warning.svg"/>
         <p><?php 
    echo esc_html(\__('The payment has been cancelled and the transaction could not be completed.', 'virement-maitrise'));
    ?></p>
    </div>
<?php 
} elseif ($status === 'payment_error' || $status === 'cms_internal_error') {
    ?>
    <div class="fintecture-alert fintecture-alert-danger">
        <img src="<?php 
    echo esc_url($imgPath);
    ?>checkout/error.svg"/>
         <p><?php 
    // translators: %1$s: merchant contact page URL, %2$s: support email address, %3$s: support email address (display text), %4$s: chat support URL.
    echo \wp_kses_post(\sprintf(\__('A technical error has occurred. Please contact <a href="%1$s" target="_blank">the merchant</a> or Société Générale by email at <a href="mailto:%2$s">%3$s</a> or via <a href="%4$s" target="_blank">chat</a>.', 'virement-maitrise'), esc_url($contactPageUrl), 'support@virementmaitrise.societegenerale.eu', 'support@virementmaitrise.societegenerale.eu', 'https://help.virementmaitrise.societegenerale.eu'));
    ?></p>
    </div>
<?php 
}
