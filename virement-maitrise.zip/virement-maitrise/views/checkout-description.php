<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<?php if ($checkoutDesign === 'it') { ?>
    <div id="f-wc-section">
        <div id="f-wc-dropdown">
            <p id="f-wc-dropdown-text">
                <?php echo esc_html(__('You will be automatically redirected to your secured bank environment to confirm your payment.', 'virement-maitrise')); ?><br>
                <b><?php echo esc_html(__('Pay safely for your purchase. It\'s easy, no registration needed.', 'virement-maitrise')); ?></b>
                <span id="f-wc-howto">
                    <?php echo esc_html(__('How it works?', 'virement-maitrise')); ?>
                    <span id="f-wc-dropdown-arrow"></span>
                </span>
            </p>
            <div id="f-wc-dropdown-content">
                <div id="f-wc-steps">
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-1-icon">
                            <div class="f-wc-step-img f-wc-step-1-img"></div>
                        </div>
                        <div>1. <?php echo esc_html(__('Select your bank', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-2-icon">
                            <div class="f-wc-step-img f-wc-step-2-img"></div>
                        </div>
                        <div>2. <?php echo esc_html(__('Login with your usual banking ID\'s', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-3-icon">
                            <div class="f-wc-step-img f-wc-step-3-img"></div>
                        </div>
                        <div>3. <?php echo esc_html(__('Confirm your payment securely', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-4-icon">
                            <div class="f-wc-step-img f-wc-step-4-img"></div>
                        </div>
                        <div>4. <?php echo esc_html(__('Your purchase is confirmed!', 'virement-maitrise')); ?></div>
                    </div>
                </div>
            </div>
            <p id="f-institution"><?php echo esc_html(__('Société Générale is a payment institution supervised by the Banque de France and the ACPR under the N°56741.', 'virement-maitrise')); ?></p>
        </div>
    </div>
<?php } else { ?>
    <div id="f-wc-section">
        <div id="f-wc-dropdown">
            <p id="f-wc-dropdown-text">
                <?php echo esc_html(__('Choose to pay by ', 'virement-maitrise')); ?>
                <b><?php echo esc_html(__('Classic Transfer', 'virement-maitrise')); ?></b>
                <?php echo esc_html(__('or by', 'virement-maitrise')); ?>
                <b><?php echo esc_html(__('Simplified Transfer', 'virement-maitrise')); ?></b>
                <?php echo esc_html(__(', for an express payment of your purchases.', 'virement-maitrise')); ?>
                <span id="f-wc-howto">
                    <?php echo esc_html(__('How to make an Simplified Transfer?', 'virement-maitrise')); ?>
                    <span id="f-wc-dropdown-arrow"></span>
                </span>
            </p>
            <div id="f-wc-dropdown-content">
                <div id="f-wc-steps">
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-1-icon">
                            <div class="f-wc-step-img f-wc-step-1-img"></div>
                        </div>
                        <div>1. <?php echo esc_html(__('Select your bank', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-2-icon">
                            <div class="f-wc-step-img f-wc-step-2-img"></div>
                        </div>
                        <div>2. <?php echo esc_html(__('Login with your usual banking ID\'s', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-3-icon">
                            <div class="f-wc-step-img f-wc-step-3-img"></div>
                        </div>
                        <div>3. <?php echo esc_html(__('Confirm your payment securely', 'virement-maitrise')); ?></div>
                    </div>
                    <div class="f-wc-step-wrapper">
                        <div class="f-wc-step-icon f-wc-step-4-icon">
                            <div class="f-wc-step-img f-wc-step-4-img"></div>
                        </div>
                        <div>4. <?php echo esc_html(__('Your purchase is confirmed!', 'virement-maitrise')); ?></div>
                    </div>
                </div>
            </div>
            <p id="f-institution"><?php echo esc_html(__('Société Générale is a payment institution supervised by the Banque de France and the ACPR under the N°56741.', 'virement-maitrise')); ?></p>
        </div>
    </div>
<?php } ?>
